title: Oracle-PLSQL删除【delete】数据闪回恢复
date: '2019-09-11 11:33:54'
updated: '2019-09-11 11:33:54'
tags: [Oracle]
permalink: /articles/2019/09/11/1568172834830.html
---
![](https://img.hacpai.com/bing/20181013.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

# begin（时间闪回恢复）：
* 闪回前提条件：
	* 该表的Flashback权限
	* 拥有该表的SELECT\INSERT\DELETE\ALTER权限
	* 必须保证表示ROW MOVEMENT
	* 采用PURGE参数删除表中数据时不能使用Flashback进行恢复
### 1.拿一张表来测试：
![image.png](https://img.hacpai.com/file/2019/09/image-2e1273db.png)

### 2.删除数据，并提交：
![image.png](https://img.hacpai.com/file/2019/09/image-68c0e850.png)


### 3.在闪回之前需要执行语句：

```sql
alter table 【你的表名】 enable row movement

#我这里是：
alter table T0016_BASEVOLTAGE enable row movement
```

### 4.在闪回前，需要找到误删时间点：
```
#这个查询是查询数据库的历史操作记录，里面包含着你历史的操作语句和时间点。
#因为数据太多，所以可以写个where子查询，SQL_TEXT操作语句，筛选自己的表名：
```
![image.png](https://img.hacpai.com/file/2019/09/image-2dfb04c7.png)


```
#找到时间字段：
```
![image.png](https://img.hacpai.com/file/2019/09/image-1ec61794.png)


### 5.闪回执行语句：

![image.png](https://img.hacpai.com/file/2019/09/image-78f715cc.png)

### 6.完成：
![image.png](https://img.hacpai.com/file/2019/09/image-f4bc8e00.png)





